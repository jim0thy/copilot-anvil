# Anvil

A lightweight agentic development environment built on [Electrobun](https://blackboard.sh/electrobun/) + [GitHub Copilot SDK](https://github.com/github/copilot-sdk). Inspired by [T3 Code](https://t3.codes) and [JetBrains Air](https://air.dev).

Anvil is a thin desktop shell around the native Copilot agent harness — no custom orchestration, no plugin system, just the SDK's production-tested planning, tool invocation, and execution loop wrapped in a task-oriented UI.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Electrobun (CEF)                                       │
│  ┌───────────────┐    typed RPC    ┌──────────────────┐ │
│  │   Bun Main    │◄──────────────►│   React Webview   │ │
│  │   Process     │                │   (shadcn/ui)     │ │
│  │               │                │                    │ │
│  │  CopilotBridge│                │  useAnvil() hook   │ │
│  │  ├ sessions   │                │  ├ TaskSidebar     │ │
│  │  ├ events     │                │  ├ AgentStream     │ │
│  │  └ tools      │                │  ├ PromptBar       │ │
│  │               │                │  └ TerminalPanel   │ │
│  └───────┬───────┘                └──────────────────┘ │
│          │ JSON-RPC                                     │
│  ┌───────▼───────┐                                      │
│  │  Copilot CLI  │  (server mode, managed by SDK)       │
│  └───────────────┘                                      │
└─────────────────────────────────────────────────────────┘
```

### Layers

| Layer | Tech | Role |
|-------|------|------|
| Shell | Electrobun + CEF | Desktop window, native menus, code signing |
| Main process | Bun + `@github/copilot-sdk` | Session lifecycle, event bridging via typed RPC |
| Renderer | React 19 + shadcn/ui + Tailwind v4 | Task-oriented UI with streaming, diffs, terminal |
| Agent | Copilot CLI (server mode) | Planning, tool invocation, file edits, model routing |

### Key design decisions

- **Task-oriented, not chat-oriented.** Each CopilotSession maps to a Task with a lifecycle (running → input_required → done) and semantic output blocks (text, tool calls, diffs, plan steps).
- **Agent-agnostic harness.** The Copilot SDK supports multiple models (GPT-5, Claude, Gemini, o3) and BYOK. The UI exposes model selection per-task.
- **Approval gates.** File diffs surface as reviewable inline blocks with Apply/Reject actions — the Air/T3 Code pattern.
- **CEF renderer.** Ensures xterm.js, CodeMirror, and shadcn components render identically across platforms.

## Project structure

```
anvil/
├── src/
│   ├── bun/
│   │   ├── index.ts           # Electrobun window + RPC handlers
│   │   └── copilot.ts         # CopilotBridge: thin SDK wrapper
│   ├── shared/
│   │   └── types.ts           # Typed RPC contract (AnvilRPC)
│   └── mainview/
│       ├── index.html          # HTML shell
│       ├── index.tsx           # Electroview RPC + React mount
│       ├── app.tsx             # Root layout (3-panel)
│       ├── styles.css          # Tailwind v4 + shadcn variables
│       ├── lib/
│       │   └── utils.ts        # cn() utility
│       ├── hooks/
│       │   └── use-anvil.ts    # State management + RPC bridge
│       └── components/
│           ├── task-sidebar.tsx
│           ├── agent-stream.tsx
│           ├── tool-call-block.tsx
│           ├── diff-block.tsx
│           ├── plan-step-block.tsx
│           ├── prompt-bar.tsx
│           └── terminal-panel.tsx
├── electrobun.config.ts
├── package.json
└── tsconfig.json
```

## Getting started

### Prerequisites

- [Bun](https://bun.sh) installed globally
- [GitHub Copilot CLI](https://github.com/github/copilot-sdk) installed and authenticated
- A Copilot subscription (or BYOK keys)

### Install and run

```bash
cd anvil
bun install
bun dev
```

### Build for distribution

```bash
bun run build:canary   # or build:stable
```

## Next steps

- [ ] Wire PTY to terminal panel (bun:ffi or node-pty → xterm.js)
- [ ] Replace simple markdown renderer with proper remark/rehype pipeline
- [ ] Add CodeMirror 6 for richer diff viewing
- [ ] Add worktree/git integration (per T3 Code pattern)
- [ ] Add permission/input prompt modals (currently inline)
- [ ] Add settings panel (BYOK keys, MCP server config)
- [ ] Keyboard shortcuts (Cmd+N new task, Cmd+Enter submit, Cmd+` terminal)
