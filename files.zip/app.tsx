import { useState } from "react";
import { useAnvil } from "./hooks/use-anvil";
import { TaskSidebar } from "./components/task-sidebar";
import { AgentStream } from "./components/agent-stream";
import { PromptBar } from "./components/prompt-bar";
import { TerminalPanel } from "./components/terminal-panel";
import { cn } from "./lib/utils";

export function App() {
  const anvil = useAnvil();
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [terminalHeight, setTerminalHeight] = useState(200);

  return (
    <div className="flex h-screen flex-col bg-[hsl(var(--anvil-surface-0))]">
      {/* ─── Title bar (draggable) ─────────────────────────────────────── */}
      <div className="drag-region flex h-10 shrink-0 items-center border-b border-[hsl(var(--border))] px-20">
        <span className="no-drag text-xs font-medium text-[hsl(var(--muted-foreground))]">
          Anvil
        </span>
      </div>

      {/* ─── Main area ─────────────────────────────────────────────────── */}
      <div className="flex flex-1 overflow-hidden">
        {/* ─── Sidebar ─────────────────────────────────────────────────── */}
        <TaskSidebar
          tasks={anvil.tasks}
          activeTaskId={anvil.activeTaskId}
          onSelectTask={anvil.setActiveTaskId}
          onNewTask={() => {
            anvil.setActiveTaskId(null);
          }}
        />

        {/* ─── Centre + Bottom ─────────────────────────────────────────── */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* ─── Agent stream ──────────────────────────────────────────── */}
          <div className="flex-1 overflow-hidden">
            <AgentStream
              task={anvil.activeTask}
              onApproveDiff={(file) =>
                anvil.activeTask &&
                anvil.approveDiff(anvil.activeTask.id, file)
              }
              onRejectDiff={(file, feedback) =>
                anvil.activeTask &&
                anvil.rejectDiff(anvil.activeTask.id, file, feedback)
              }
            />
          </div>

          {/* ─── Terminal panel (collapsible) ──────────────────────────── */}
          {terminalOpen && (
            <div
              className="border-t border-[hsl(var(--border))]"
              style={{ height: terminalHeight }}
            >
              <TerminalPanel />
            </div>
          )}

          {/* ─── Prompt bar ────────────────────────────────────────────── */}
          <PromptBar
            activeTask={anvil.activeTask}
            models={anvil.models}
            selectedModel={anvil.selectedModel}
            onSelectModel={anvil.setSelectedModel}
            onSubmit={async (prompt, mode) => {
              if (anvil.activeTask && anvil.activeTask.status !== "done") {
                await anvil.respondToTask(anvil.activeTask.id, prompt);
              } else {
                await anvil.createTask(prompt, mode);
              }
            }}
            terminalOpen={terminalOpen}
            onToggleTerminal={() => setTerminalOpen((prev) => !prev)}
          />
        </div>
      </div>
    </div>
  );
}
