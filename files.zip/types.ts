import type { RPCSchema } from "electrobun/bun";

// ─── Domain Types ───────────────────────────────────────────────────────────

export type TaskStatus =
  | "idle"
  | "running"
  | "input_required"
  | "done"
  | "cancelled"
  | "error";

export type TaskMode = "chat" | "plan";
export type AccessMode = "supervised" | "full";

export interface TaskSummary {
  id: string;
  title: string;
  status: TaskStatus;
  model: string;
  mode: TaskMode;
  createdAt: number;
}

export interface DiffHunk {
  oldStart: number;
  oldLines: number;
  newStart: number;
  newLines: number;
  content: string;
}

export interface FileDiff {
  file: string;
  hunks: DiffHunk[];
  additions: number;
  deletions: number;
}

export interface ToolCallInfo {
  id: string;
  tool: string;
  input: Record<string, unknown>;
  output?: string;
  status: "running" | "done" | "error";
}

export interface ModelInfo {
  id: string;
  name: string;
  provider: string;
}

// ─── RPC Schema ─────────────────────────────────────────────────────────────

export type AnvilRPC = {
  // Functions that execute in the Bun main process (called from webview)
  bun: RPCSchema<{
    requests: {
      // Task lifecycle
      createTask: {
        params: {
          prompt: string;
          model?: string;
          mode?: TaskMode;
          accessMode?: AccessMode;
        };
        response: TaskSummary;
      };
      cancelTask: {
        params: { taskId: string };
        response: { success: boolean };
      };
      respondToTask: {
        params: { taskId: string; input: string };
        response: { success: boolean };
      };

      // Diff review
      approveDiff: {
        params: { taskId: string; file: string };
        response: { success: boolean };
      };
      rejectDiff: {
        params: { taskId: string; file: string; feedback?: string };
        response: { success: boolean };
      };

      // Task queries
      listTasks: {
        params: Record<string, never>;
        response: TaskSummary[];
      };
      getAvailableModels: {
        params: Record<string, never>;
        response: ModelInfo[];
      };

      // Terminal
      sendTerminalInput: {
        params: { data: string };
        response: { success: boolean };
      };
      resizeTerminal: {
        params: { cols: number; rows: number };
        response: { success: boolean };
      };

      // Project
      openProject: {
        params: { path: string };
        response: { success: boolean; name: string };
      };
      getProjectInfo: {
        params: Record<string, never>;
        response: { path: string; name: string } | null;
      };
    };
    messages: {
      log: { level: string; message: string };
    };
  }>;

  // Functions that execute in the webview (called from Bun)
  webview: RPCSchema<{
    requests: {
      // Prompt user for input when agent needs it
      promptUserInput: {
        params: { taskId: string; question: string };
        response: string;
      };
      // Prompt user for permission when agent requests tool use
      promptPermission: {
        params: {
          taskId: string;
          tool: string;
          description: string;
        };
        response: boolean;
      };
    };
    messages: {
      // Streaming agent output
      streamText: { taskId: string; text: string };
      streamToolCall: { taskId: string; toolCall: ToolCallInfo };
      streamDiff: { taskId: string; diff: FileDiff };
      streamPlanStep: {
        taskId: string;
        step: { index: number; description: string; done: boolean };
      };

      // Task state changes
      taskStatusChanged: { taskId: string; status: TaskStatus; error?: string };
      taskTitleUpdated: { taskId: string; title: string };

      // Terminal
      terminalOutput: { data: string };

      // Models
      modelsUpdated: { models: ModelInfo[] };
    };
  }>;
};
