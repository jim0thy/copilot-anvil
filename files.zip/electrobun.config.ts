import type { ElectrobunConfig } from "electrobun";

export default {
  app: {
    name: "Anvil",
    identifier: "dev.anvil.app",
    version: "0.1.0",
  },
  runtime: {
    exitOnLastWindowClosed: true,
    defaultRenderer: "cef",
  },
  build: {
    bun: {
      entrypoint: "src/bun/index.ts",
    },
    views: {
      mainview: {
        entrypoint: "src/mainview/index.tsx",
      },
    },
    copy: {
      "src/mainview/index.html": "views/mainview/index.html",
      "src/mainview/styles.css": "views/mainview/styles.css",
    },
    mac: {
      bundleCEF: true,
    },
    linux: {
      bundleCEF: true,
    },
    win: {
      bundleCEF: true,
    },
  },
} satisfies ElectrobunConfig;
