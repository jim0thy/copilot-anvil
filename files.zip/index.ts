import {
  BrowserWindow,
  BrowserView,
  ApplicationMenu,
} from "electrobun/bun";
import type { AnvilRPC } from "../shared/types";
import { CopilotBridge } from "./copilot";

// ─── RPC Handlers ───────────────────────────────────────────────────────────

// We need a reference to the webview to send messages back
let webview: BrowserView | null = null;

const bridge = new CopilotBridge({
  onStreamText: (taskId, text) => {
    webview?.rpc.streamText({ taskId, text });
  },
  onStreamToolCall: (taskId, toolCall) => {
    webview?.rpc.streamToolCall({ taskId, toolCall });
  },
  onStreamDiff: (taskId, diff) => {
    webview?.rpc.streamDiff({ taskId, diff });
  },
  onStreamPlanStep: (taskId, step) => {
    webview?.rpc.streamPlanStep({ taskId, step });
  },
  onTaskStatusChanged: (taskId, status, error) => {
    webview?.rpc.taskStatusChanged({ taskId, status, error });
  },
  onTaskTitleUpdated: (taskId, title) => {
    webview?.rpc.taskTitleUpdated({ taskId, title });
  },
  onRequestUserInput: async (taskId, question) => {
    if (!webview) return "";
    return webview.rpc.promptUserInput({ taskId, question });
  },
  onRequestPermission: async (taskId, tool, description) => {
    if (!webview) return false;
    return webview.rpc.promptPermission({ taskId, tool, description });
  },
});

// ─── Define Bun-side RPC ────────────────────────────────────────────────────

const rpc = BrowserView.defineRPC<AnvilRPC>({
  maxRequestTime: 30_000,
  handlers: {
    requests: {
      createTask: async (params) => {
        return bridge.createTask(params);
      },
      cancelTask: async ({ taskId }) => {
        const success = await bridge.cancelTask(taskId);
        return { success };
      },
      respondToTask: async ({ taskId, input }) => {
        const success = await bridge.respondToTask(taskId, input);
        return { success };
      },
      approveDiff: async ({ taskId, file }) => {
        // TODO: wire to Copilot SDK's file approval mechanism
        console.log(`[anvil] Approved diff: ${file} in task ${taskId}`);
        return { success: true };
      },
      rejectDiff: async ({ taskId, file, feedback }) => {
        // TODO: wire to Copilot SDK's diff rejection with feedback
        console.log(
          `[anvil] Rejected diff: ${file} in task ${taskId}`,
          feedback
        );
        return { success: true };
      },
      listTasks: () => {
        return bridge.listTasks();
      },
      getAvailableModels: async () => {
        return bridge.getAvailableModels();
      },
      sendTerminalInput: async ({ data }) => {
        // TODO: PTY integration
        console.log(`[anvil] Terminal input: ${data}`);
        return { success: true };
      },
      resizeTerminal: async ({ cols, rows }) => {
        // TODO: PTY resize
        console.log(`[anvil] Terminal resize: ${cols}x${rows}`);
        return { success: true };
      },
      openProject: async ({ path }) => {
        const name = path.split("/").pop() ?? path;
        console.log(`[anvil] Opening project: ${path}`);
        return { success: true, name };
      },
      getProjectInfo: async () => {
        return { path: process.cwd(), name: process.cwd().split("/").pop() ?? "" };
      },
    },
    messages: {
      log: ({ level, message }) => {
        console.log(`[webview:${level}] ${message}`);
      },
    },
  },
});

// ─── Window ─────────────────────────────────────────────────────────────────

const win = new BrowserWindow({
  title: "Anvil",
  url: "views://mainview/index.html",
  renderer: "cef",
  frame: {
    width: 1280,
    height: 820,
    x: 200,
    y: 100,
  },
  titleBarStyle: "hiddenInset",
  rpc,
});

webview = win.webview;

// ─── Application Menu ───────────────────────────────────────────────────────

ApplicationMenu.setApplicationMenu([
  {
    label: "Anvil",
    submenu: [
      { label: "About Anvil", role: "about" },
      { type: "separator" },
      { label: "Settings…", accelerator: "CmdOrCtrl+,", action: () => {} },
      { type: "separator" },
      { label: "Quit", accelerator: "CmdOrCtrl+Q", role: "quit" },
    ],
  },
  {
    label: "Edit",
    submenu: [
      { label: "Undo", accelerator: "CmdOrCtrl+Z", role: "undo" },
      { label: "Redo", accelerator: "Shift+CmdOrCtrl+Z", role: "redo" },
      { type: "separator" },
      { label: "Cut", accelerator: "CmdOrCtrl+X", role: "cut" },
      { label: "Copy", accelerator: "CmdOrCtrl+C", role: "copy" },
      { label: "Paste", accelerator: "CmdOrCtrl+V", role: "paste" },
      { label: "Select All", accelerator: "CmdOrCtrl+A", role: "selectAll" },
    ],
  },
  {
    label: "View",
    submenu: [
      {
        label: "Toggle Developer Tools",
        accelerator: "Alt+CmdOrCtrl+I",
        role: "toggleDevTools",
      },
      { type: "separator" },
      { label: "Reload", accelerator: "CmdOrCtrl+R", role: "reload" },
    ],
  },
]);

// ─── Start Copilot ──────────────────────────────────────────────────────────

bridge.start().then(() => {
  console.log("[anvil] Ready");
}).catch((err) => {
  console.error("[anvil] Failed to start Copilot client:", err);
});
