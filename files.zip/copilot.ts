import { CopilotClient, type CopilotSession } from "@github/copilot-sdk";
import type {
  TaskSummary,
  TaskStatus,
  TaskMode,
  AccessMode,
  ModelInfo,
  FileDiff,
  ToolCallInfo,
  DiffHunk,
} from "../shared/types";

// ─── Task State ─────────────────────────────────────────────────────────────

interface ManagedTask {
  id: string;
  session: CopilotSession;
  summary: TaskSummary;
}

// ─── Event callbacks the main process wires to RPC messages ─────────────────

export interface CopilotBridgeEvents {
  onStreamText: (taskId: string, text: string) => void;
  onStreamToolCall: (taskId: string, toolCall: ToolCallInfo) => void;
  onStreamDiff: (taskId: string, diff: FileDiff) => void;
  onStreamPlanStep: (
    taskId: string,
    step: { index: number; description: string; done: boolean }
  ) => void;
  onTaskStatusChanged: (
    taskId: string,
    status: TaskStatus,
    error?: string
  ) => void;
  onTaskTitleUpdated: (taskId: string, title: string) => void;
  onRequestUserInput: (taskId: string, question: string) => Promise<string>;
  onRequestPermission: (
    taskId: string,
    tool: string,
    description: string
  ) => Promise<boolean>;
}

// ─── Bridge ─────────────────────────────────────────────────────────────────

export class CopilotBridge {
  private client: CopilotClient;
  private tasks: Map<string, ManagedTask> = new Map();
  private events: CopilotBridgeEvents;
  private taskCounter = 0;

  constructor(events: CopilotBridgeEvents) {
    this.client = new CopilotClient();
    this.events = events;
  }

  async start(): Promise<void> {
    await this.client.start();
    console.log("[anvil] Copilot client started");
  }

  async getAvailableModels(): Promise<ModelInfo[]> {
    // The SDK exposes available models at runtime
    try {
      const models = await this.client.getModels?.();
      if (models && Array.isArray(models)) {
        return models.map((m: any) => ({
          id: m.id ?? m.name,
          name: m.name ?? m.id,
          provider: m.provider ?? "copilot",
        }));
      }
    } catch {
      // Fallback if getModels isn't available in this SDK version
    }
    return [
      { id: "gpt-5", name: "GPT-5", provider: "openai" },
      { id: "claude-sonnet-4-20250514", name: "Claude Sonnet 4", provider: "anthropic" },
      { id: "o3", name: "o3", provider: "openai" },
      { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro", provider: "google" },
    ];
  }

  async createTask(opts: {
    prompt: string;
    model?: string;
    mode?: TaskMode;
    accessMode?: AccessMode;
  }): Promise<TaskSummary> {
    const id = `task_${++this.taskCounter}_${Date.now()}`;
    const model = opts.model ?? "gpt-5";

    const session = await this.client.createSession({
      model,
    });

    const summary: TaskSummary = {
      id,
      title: opts.prompt.slice(0, 80) + (opts.prompt.length > 80 ? "…" : ""),
      status: "running",
      model,
      mode: opts.mode ?? "chat",
      createdAt: Date.now(),
    };

    const task: ManagedTask = { id, session, summary };
    this.tasks.set(id, task);

    // Wire up session event listeners
    this.wireSessionEvents(task, opts.accessMode ?? "supervised");

    // Fire the prompt (non-blocking — events stream back)
    session.send({ prompt: opts.prompt }).catch((err) => {
      this.updateTaskStatus(id, "error", String(err));
    });

    return summary;
  }

  async cancelTask(taskId: string): Promise<boolean> {
    const task = this.tasks.get(taskId);
    if (!task) return false;

    try {
      await task.session.cancel?.();
    } catch {
      // Best effort
    }

    this.updateTaskStatus(taskId, "cancelled");
    return true;
  }

  async respondToTask(taskId: string, input: string): Promise<boolean> {
    const task = this.tasks.get(taskId);
    if (!task) return false;

    try {
      await task.session.send({ prompt: input });
      this.updateTaskStatus(taskId, "running");
      return true;
    } catch {
      return false;
    }
  }

  listTasks(): TaskSummary[] {
    return Array.from(this.tasks.values()).map((t) => t.summary);
  }

  // ─── Internal ───────────────────────────────────────────────────────────

  private wireSessionEvents(task: ManagedTask, accessMode: AccessMode): void {
    const { session, id } = task;

    // Text streaming
    session.on("textDelta", (delta: any) => {
      this.events.onStreamText(id, delta.text ?? delta.content ?? "");
    });

    // Tool use events
    session.on("toolCall", (call: any) => {
      const toolCall: ToolCallInfo = {
        id: call.id ?? `tool_${Date.now()}`,
        tool: call.name ?? call.tool ?? "unknown",
        input: call.input ?? call.parameters ?? {},
        status: "running",
      };
      this.events.onStreamToolCall(id, toolCall);
    });

    session.on("toolResult", (result: any) => {
      const toolCall: ToolCallInfo = {
        id: result.id ?? `tool_${Date.now()}`,
        tool: result.name ?? result.tool ?? "unknown",
        input: {},
        output: result.output ?? result.result ?? "",
        status: result.error ? "error" : "done",
      };
      this.events.onStreamToolCall(id, toolCall);
    });

    // File edit events → diffs
    session.on("fileEdit", (edit: any) => {
      const diff: FileDiff = {
        file: edit.path ?? edit.file ?? "unknown",
        hunks: edit.hunks ?? [],
        additions: edit.additions ?? 0,
        deletions: edit.deletions ?? 0,
      };
      this.events.onStreamDiff(id, diff);
    });

    // Permission handling
    if (accessMode === "supervised") {
      session.on("permissionRequest", async (req: any) => {
        const allowed = await this.events.onRequestPermission(
          id,
          req.tool ?? req.name ?? "unknown",
          req.description ?? req.message ?? "Agent requests permission"
        );
        req.respond?.(allowed);
      });
    }

    // User input requests
    session.on("userInputRequest", async (req: any) => {
      const response = await this.events.onRequestUserInput(
        id,
        req.question ?? req.message ?? "Agent needs input"
      );
      req.respond?.(response);
    });

    // Completion
    session.on("done", () => {
      this.updateTaskStatus(id, "done");
    });

    session.on("error", (err: any) => {
      this.updateTaskStatus(id, "error", String(err?.message ?? err));
    });
  }

  private updateTaskStatus(
    taskId: string,
    status: TaskStatus,
    error?: string
  ): void {
    const task = this.tasks.get(taskId);
    if (task) {
      task.summary.status = status;
    }
    this.events.onTaskStatusChanged(taskId, status, error);
  }
}
