import { Electroview } from "electrobun/view";
import { createRoot } from "react-dom/client";
import type { AnvilRPC } from "../shared/types";
import { App } from "./app";

// ─── Webview-side RPC setup ─────────────────────────────────────────────────

// We store pending request resolvers so bun can call into us
let userInputResolve: ((value: string) => void) | null = null;
let permissionResolve: ((value: boolean) => void) | null = null;

// Event bus: the React app subscribes to these
type EventHandler = (data: any) => void;
const eventHandlers: Map<string, Set<EventHandler>> = new Map();

export function onAnvilEvent(event: string, handler: EventHandler) {
  if (!eventHandlers.has(event)) eventHandlers.set(event, new Set());
  eventHandlers.get(event)!.add(handler);
  return () => eventHandlers.get(event)?.delete(handler);
}

function emitAnvilEvent(event: string, data: any) {
  eventHandlers.get(event)?.forEach((handler) => handler(data));
}

// Define the webview-side RPC handlers
const rpc = Electroview.defineRPC<AnvilRPC>({
  handlers: {
    requests: {
      promptUserInput: ({ taskId, question }) => {
        emitAnvilEvent("promptUserInput", { taskId, question });
        return new Promise<string>((resolve) => {
          userInputResolve = resolve;
        });
      },
      promptPermission: ({ taskId, tool, description }) => {
        emitAnvilEvent("promptPermission", { taskId, tool, description });
        return new Promise<boolean>((resolve) => {
          permissionResolve = resolve;
        });
      },
    },
    messages: {
      streamText: (data) => emitAnvilEvent("streamText", data),
      streamToolCall: (data) => emitAnvilEvent("streamToolCall", data),
      streamDiff: (data) => emitAnvilEvent("streamDiff", data),
      streamPlanStep: (data) => emitAnvilEvent("streamPlanStep", data),
      taskStatusChanged: (data) => emitAnvilEvent("taskStatusChanged", data),
      taskTitleUpdated: (data) => emitAnvilEvent("taskTitleUpdated", data),
      terminalOutput: (data) => emitAnvilEvent("terminalOutput", data),
      modelsUpdated: (data) => emitAnvilEvent("modelsUpdated", data),
    },
  },
});

// Expose resolve functions so React components can respond
export function resolveUserInput(value: string) {
  userInputResolve?.(value);
  userInputResolve = null;
}

export function resolvePermission(allowed: boolean) {
  permissionResolve?.(allowed);
  permissionResolve = null;
}

// Expose RPC for calling bun from React components
export { rpc };

// ─── Mount React ────────────────────────────────────────────────────────────

const root = createRoot(document.getElementById("root")!);
root.render(<App />);
