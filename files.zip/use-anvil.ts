import { useState, useEffect, useCallback, useRef } from "react";
import { rpc, onAnvilEvent } from "../index";
import type {
  TaskSummary,
  TaskStatus,
  TaskMode,
  AccessMode,
  ModelInfo,
  ToolCallInfo,
  FileDiff,
} from "../../shared/types";

// ─── Stream block types ─────────────────────────────────────────────────────

export type StreamBlock =
  | { type: "text"; content: string }
  | { type: "toolCall"; toolCall: ToolCallInfo }
  | { type: "diff"; diff: FileDiff }
  | { type: "planStep"; step: { index: number; description: string; done: boolean } }
  | { type: "userPrompt"; question: string }
  | { type: "permissionPrompt"; tool: string; description: string };

export interface TaskState extends TaskSummary {
  blocks: StreamBlock[];
  pendingText: string;
}

// ─── Hook ───────────────────────────────────────────────────────────────────

export function useAnvil() {
  const [tasks, setTasks] = useState<Map<string, TaskState>>(new Map());
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [selectedModel, setSelectedModel] = useState("gpt-5");

  // Ref for stable access in event handlers
  const tasksRef = useRef(tasks);
  tasksRef.current = tasks;

  // ─── Event subscriptions ────────────────────────────────────────────────

  useEffect(() => {
    const unsubs: (() => void)[] = [];

    unsubs.push(
      onAnvilEvent("streamText", ({ taskId, text }) => {
        setTasks((prev) => {
          const next = new Map(prev);
          const task = next.get(taskId);
          if (!task) return prev;

          // Accumulate text into the last text block, or create a new one
          const lastBlock = task.blocks[task.blocks.length - 1];
          if (lastBlock?.type === "text") {
            lastBlock.content += text;
          } else {
            task.blocks.push({ type: "text", content: text });
          }
          task.pendingText += text;
          return next;
        });
      })
    );

    unsubs.push(
      onAnvilEvent("streamToolCall", ({ taskId, toolCall }) => {
        setTasks((prev) => {
          const next = new Map(prev);
          const task = next.get(taskId);
          if (!task) return prev;

          // Update existing tool call block or add new one
          const existingIdx = task.blocks.findIndex(
            (b) => b.type === "toolCall" && b.toolCall.id === toolCall.id
          );
          if (existingIdx >= 0) {
            task.blocks[existingIdx] = { type: "toolCall", toolCall };
          } else {
            task.blocks.push({ type: "toolCall", toolCall });
          }
          return next;
        });
      })
    );

    unsubs.push(
      onAnvilEvent("streamDiff", ({ taskId, diff }) => {
        setTasks((prev) => {
          const next = new Map(prev);
          const task = next.get(taskId);
          if (!task) return prev;
          task.blocks.push({ type: "diff", diff });
          return next;
        });
      })
    );

    unsubs.push(
      onAnvilEvent("streamPlanStep", ({ taskId, step }) => {
        setTasks((prev) => {
          const next = new Map(prev);
          const task = next.get(taskId);
          if (!task) return prev;

          // Update existing step or add new
          const existingIdx = task.blocks.findIndex(
            (b) => b.type === "planStep" && b.step.index === step.index
          );
          if (existingIdx >= 0) {
            task.blocks[existingIdx] = { type: "planStep", step };
          } else {
            task.blocks.push({ type: "planStep", step });
          }
          return next;
        });
      })
    );

    unsubs.push(
      onAnvilEvent("taskStatusChanged", ({ taskId, status, error }) => {
        setTasks((prev) => {
          const next = new Map(prev);
          const task = next.get(taskId);
          if (task) {
            task.status = status as TaskStatus;
          }
          return next;
        });
      })
    );

    unsubs.push(
      onAnvilEvent("taskTitleUpdated", ({ taskId, title }) => {
        setTasks((prev) => {
          const next = new Map(prev);
          const task = next.get(taskId);
          if (task) task.title = title;
          return next;
        });
      })
    );

    unsubs.push(
      onAnvilEvent("modelsUpdated", ({ models: newModels }) => {
        setModels(newModels);
      })
    );

    return () => unsubs.forEach((fn) => fn());
  }, []);

  // ─── Load models on mount ───────────────────────────────────────────────

  useEffect(() => {
    rpc.getAvailableModels({}).then(setModels).catch(console.error);
  }, []);

  // ─── Actions ────────────────────────────────────────────────────────────

  const createTask = useCallback(
    async (prompt: string, mode: TaskMode = "chat", accessMode: AccessMode = "supervised") => {
      const summary = await rpc.createTask({
        prompt,
        model: selectedModel,
        mode,
        accessMode,
      });

      const taskState: TaskState = {
        ...summary,
        blocks: [],
        pendingText: "",
      };

      setTasks((prev) => {
        const next = new Map(prev);
        next.set(summary.id, taskState);
        return next;
      });
      setActiveTaskId(summary.id);
      return summary;
    },
    [selectedModel]
  );

  const respondToTask = useCallback(async (taskId: string, input: string) => {
    // Add the user message as a text block
    setTasks((prev) => {
      const next = new Map(prev);
      const task = next.get(taskId);
      if (task) {
        task.blocks.push({ type: "text", content: `\n\n**You:** ${input}\n\n` });
      }
      return next;
    });
    await rpc.respondToTask({ taskId, input });
  }, []);

  const cancelTask = useCallback(async (taskId: string) => {
    await rpc.cancelTask({ taskId });
  }, []);

  const approveDiff = useCallback(async (taskId: string, file: string) => {
    await rpc.approveDiff({ taskId, file });
  }, []);

  const rejectDiff = useCallback(
    async (taskId: string, file: string, feedback?: string) => {
      await rpc.rejectDiff({ taskId, file, feedback });
    },
    []
  );

  // ─── Derived state ─────────────────────────────────────────────────────

  const activeTask = activeTaskId ? tasks.get(activeTaskId) ?? null : null;
  const taskList = Array.from(tasks.values()).sort(
    (a, b) => b.createdAt - a.createdAt
  );

  return {
    // State
    tasks: taskList,
    activeTask,
    activeTaskId,
    models,
    selectedModel,

    // Setters
    setActiveTaskId,
    setSelectedModel,

    // Actions
    createTask,
    respondToTask,
    cancelTask,
    approveDiff,
    rejectDiff,
  };
}
